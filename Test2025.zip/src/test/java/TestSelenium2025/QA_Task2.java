package TestSelenium2025;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.time.Duration;

public class QA_Task2 {

    private WebDriver driver;
    private WebDriverWait wait;
    private SoftAssert softAssert;

    @BeforeTest
    public void setup() throws InterruptedException {

        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver\\chromedriver-win64\\chromedriver.exe");

        // Initialize the ChromeDriver with the options
        this.driver = new ChromeDriver();
        Actions action = new Actions(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        softAssert = new SoftAssert();
        // Maximize the browser window
        driver.manage().window().maximize();

    }

    @Test (priority = 0)
    public void OpenBrowserAndExecute() throws InterruptedException, IOException {

        // Open website
        driver.get("https://www.amaysim.com.au/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        Thread.sleep(2000);

        // Click sim plans
        WebElement SimPlansMenu = driver.findElement(By.xpath("//a[@aria-label='SIM plans' and @href='/sim-plans']"));
        Actions actions = new Actions(driver);
        actions.moveToElement(SimPlansMenu).perform();

        //click 7-day sim plan
        driver.findElement(By.xpath("//a[@href='/sim-plans/7-day-sim-plans']")).click();
        Thread.sleep(500);

        //click buy now
        driver.findElement(By.xpath("//a[@href='/mobile/cart/7-day-10gb' and contains (text(),'Buy now')]")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        Thread.sleep(5000);

        //select pick a new number
        wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//div[@class='css-1sts3bo']"))));
        driver.findElement(By.xpath("//span[@class='css-15xa8x' and contains(text(),'pick a new number')]")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        //click checkout
        wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//a[@data-testid='product-checkout-button' and @class='css-1957xzp']"))));
        driver.findElement(By.xpath("//a[@data-testid='product-checkout-button']")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        Thread.sleep(1000);

        //for new customer - fill up fields
        driver.findElement(By.xpath("//input[@name='firstName' and @type='text']")).sendKeys("Test");
        driver.findElement(By.xpath("//input[@name='lastName' and @type='text']")).sendKeys("Lupin");
        driver.findElement(By.xpath("//input[@name='dateOfBirth' and @type='text']")).sendKeys("02/03/1992");
        driver.findElement(By.xpath("//input[@type='email' and @name='email']")).sendKeys("tlupin23@gmail.com");
        driver.findElement(By.xpath("//input[@type='password' and @name='password']")).sendKeys("tlupin23");
        driver.findElement(By.xpath("//input[@type='tel' and @name='contactNumber']")).sendKeys("0419922302");
        driver.findElement(By.xpath("//input[@type='text' and @class='react-autosuggest__input']")).sendKeys("Level 6, 17-19 Bridge St, SYDNEY NSW 2000");
        wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//div[@id='react-autowhatever-1']"))));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//li[@data-suggestion-index='0']")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        Thread.sleep(500);

        //select payment
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,750)", "");
        driver.switchTo().frame(driver.findElement(By.xpath("//div[@id='payment-element']//iframe")));
        driver.findElement(By.xpath("//button[@id='card-tab']")).click();
        driver.findElement(By.xpath("//input[@type='text' and @inputmode='numeric' and @id='Field-numberInput']")).sendKeys("4242424242424242");
        driver.findElement(By.xpath("//input[@type='text' and @inputmode='numeric' and @id='Field-expiryInput']")).sendKeys("0127");
        driver.findElement(By.xpath("//input[@type='text' and @inputmode='numeric' and @id='Field-cvcInput']")).sendKeys("123");
        driver.switchTo().defaultContent();

        //click terms and conditions and click pay now
        js.executeScript("window.scrollBy(0,750)", "");
        driver.findElement(By.xpath("(//div[@class='css-1417z9a'])[2]")).click();
        //driver.findElement(By.xpath("//input[@type='checkbox' and @name='acceptTermsAndConditions']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button[contains(text(), 'pay now')]")).click();

        //assert error message
        WebElement ErrorMessage = driver.findElement(By.xpath("//strong[contains(text(),'Credit Card payment failed')]"));
        String ExpectedErrorMessage = "Credit Card payment failed";
        Assert.assertEquals(ErrorMessage.getText(),ExpectedErrorMessage);


    }
}
